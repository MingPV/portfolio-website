    var selectedSubject_1 = new Set();
   var selectedSubject_2 = new Set();
 
   var notNormalSubject = new Set();
   var groups = []; // done
   var courses = {}; // done

   var matchgroup_to_id = {}; // done
   var matchid_to_group = {}; // done
   var matchcourse_to_cvcid = {}; 
   var matchcvcid_to_course = {};
 
   var is_render_current_group = "false";
   var is_set_current_group = false;
   var currentGroup = "";
   var currentSubGroup = "";
 
   var summarizeData = {abnormalCourse:{},};
   var checkNormal = {};

   var abnormal_Set = {};
   var abnormal_groupSet = new Set();
   var abnormal_course_Set = new Set();
   var abnormal_data = {};

   var wait_to_insert_group = new Set();
   var already_indb_group = new Set();

   var content_summarization_coursegroup = [];
   var content_summarization_coursegroup_course = {};

   var is_render_abnormal = {};

   var plan_height = 10;
   var note_height = 10;

   //var is_view_mode = true;

   // use only "data-key" to access "data-value"
   // data-key is created by groupName + "_" + courseNumber
   // example group : groupA
   //         course : 221567
   // data-key = "groupA_221567"
  //  var allData = {};

   var allcourses = [];
   var match_course_name = {};
   var report = null;
   var report_section = null;
   var section_id = null;
   var report_id = null;

   var is_loaded = false;

   const createAbnormalItem = (
    course_no,
    course_name,
    cv_cid,
    abnormal_cause,
    abnormal_improvement,
    is_view_mode,
  ) => `
          <li data-value="${course_no}" class="grid grid-cols-12 gap-8 my-1 mb-2 mx-2 p-2 bg-white rounded-md">
        <div class=" col-span-2 flex flex-col items-start justify-center ml-2">
          <div>${course_no}</div>
          <div class="text-xs text-center">${course_name}</div>
          <div class="text-xs">(${cv_cid})</div>
        </div>
        <div class="col-span-4">
          <textarea
            class="abnormal_cause_text"
            ${is_view_mode ? 'disabled' : ''}
          >${abnormal_cause}</textarea>
        </div>
        <div class="col-span-5 col-span-6-print">
          <textarea
            class="abnormal_improvement_text"
            ${is_view_mode ? 'disabled' : ''}
          >${abnormal_improvement}</textarea>
        </div>
        <div class="col-span-1 flex items-center justify-center">
          <button class="deleteAbnormalCourse bg-red-700 text-white py-2 px-4 rounded-lg ${is_view_mode ? 'hidden' : ''}">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M2.8125 1.125C2.51413 1.125 2.22798 1.24353 2.017 1.4545C1.80603 1.66548 1.6875 1.95163 1.6875 2.25V3.375C1.6875 3.67337 1.80603 3.95952 2.017 4.1705C2.22798 4.38147 2.51413 4.5 2.8125 4.5H3.375V14.625C3.375 15.2217 3.61205 15.794 4.03401 16.216C4.45597 16.6379 5.02826 16.875 5.625 16.875H12.375C12.9717 16.875 13.544 16.6379 13.966 16.216C14.3879 15.794 14.625 15.2217 14.625 14.625V4.5H15.1875C15.4859 4.5 15.772 4.38147 15.983 4.1705C16.194 3.95952 16.3125 3.67337 16.3125 3.375V2.25C16.3125 1.95163 16.194 1.66548 15.983 1.4545C15.772 1.24353 15.4859 1.125 15.1875 1.125H11.25C11.25 0.826631 11.1315 0.540483 10.9205 0.329505C10.7095 0.118526 10.4234 0 10.125 0L7.875 0C7.57663 0 7.29048 0.118526 7.0795 0.329505C6.86853 0.540483 6.75 0.826631 6.75 1.125H2.8125ZM6.1875 5.625C6.33668 5.625 6.47976 5.68426 6.58525 5.78975C6.69074 5.89524 6.75 6.03832 6.75 6.1875V14.0625C6.75 14.2117 6.69074 14.3548 6.58525 14.4602C6.47976 14.5657 6.33668 14.625 6.1875 14.625C6.03832 14.625 5.89524 14.5657 5.78975 14.4602C5.68426 14.3548 5.625 14.2117 5.625 14.0625V6.1875C5.625 6.03832 5.68426 5.89524 5.78975 5.78975C5.89524 5.68426 6.03832 5.625 6.1875 5.625ZM9 5.625C9.14918 5.625 9.29226 5.68426 9.39775 5.78975C9.50324 5.89524 9.5625 6.03832 9.5625 6.1875V14.0625C9.5625 14.2117 9.50324 14.3548 9.39775 14.4602C9.29226 14.5657 9.14918 14.625 9 14.625C8.85082 14.625 8.70774 14.5657 8.60225 14.4602C8.49676 14.3548 8.4375 14.2117 8.4375 14.0625V6.1875C8.4375 6.03832 8.49676 5.89524 8.60225 5.78975C8.70774 5.68426 8.85082 5.625 9 5.625ZM12.375 6.1875V14.0625C12.375 14.2117 12.3157 14.3548 12.2102 14.4602C12.1048 14.5657 11.9617 14.625 11.8125 14.625C11.6633 14.625 11.5202 14.5657 11.4148 14.4602C11.3093 14.3548 11.25 14.2117 11.25 14.0625V6.1875C11.25 6.03832 11.3093 5.89524 11.4148 5.78975C11.5202 5.68426 11.6633 5.625 11.8125 5.625C11.9617 5.625 12.1048 5.68426 12.2102 5.78975C12.3157 5.89524 12.375 6.03832 12.375 6.1875Z" fill="white"/>
              </svg>
          </button>
        </div>
      </li>
`;

   function insert_course(course_obj){
    const url = "?q=courseville/ajax/cvtqf7_insertcourse";
    console.log("COCO");
    console.log(course_obj);
    const data = {cv_cid : null,
                  coursegroup_id : course_obj.coursegroup_id,
                  improvement_plan : course_obj.improvement_plan,
                  remark : course_obj.remark,
                  is_abnormal : course_obj.is_abnormal,
                  abnormal_improvement : course_obj.abnormal_improvement,
                  abnormal_cause : course_obj.abnormal_cause,
                  course_no : course_obj.course_no,
                  };

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          matchcourse_to_cvcid[rp.data.data.course_no] = rp.data.data.cv_cid;

          if(course_obj["is_abnormal"] == 1){
            abnormal_course_Set.add(rp.data.data.course_no);
            abnormal_groupSet.add(course_obj.coursegroup_id);
            if(typeof abnormal_Set[course_obj.coursegroup_id] !== "undefined"){
              abnormal_Set[course_obj.coursegroup_id].add(rp.data.data.course_no);
            }else{
              abnormal_Set[course_obj.coursegroup_id] = new Set([rp.data.data.course_no]);
            }
            abnormal_data[rp.data.data.course_no] = {abnormal_cause:summarizeData["abnormalCourse"][rp.data.data.course_no]["cause"],
                                                     abnormal_improvement : summarizeData["abnormalCourse"][rp.data.data.course_no]["plan"]
            }

            if(typeof is_render_abnormal[rp.data.data.course_no] !== "undefined"){
              console.log("is rendered")
            }else{
              renderAbnormalCourse(rp.data.data.course_no);
              is_render_abnormal[rp.data.data.course_no]  = true;
            }

            //renderAbnormalCourse(rp.data.data.course_no);
          }

          console.log("insert successs");        
      } else {
        console.log("Green");
        console.log(matchgroup_to_id);
        console.log(rp.data);
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

  function insert_group2(insert_order,current_summarizeData){

    var group_name = "";
    group_name = insert_order.pop();
    already_indb_group.add(group_name);

    const url = "?q=courseville/ajax/cvtqf7_insertcoursegroup";
    const data = {content_summarization_id :Number(report_section.content_summarization_id),
                  coursegroup_title : group_name, 
                  };

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          console.log("insert group success");
          console.log(rp);
          console.log(data);

          // edit coursegroup_id in this allData,summarizeData

          //update matchgroup_to_id
          matchgroup_to_id[group_name] = rp.data.data.coursegroup_id;
          matchid_to_group[rp.data.data.coursegroup_id] = group_name;

          for(let element of courses[group_name]){
            // console.log("zaza")

            //update summarizeData
            summarizeData[group_name][element]["coursegroup_id"] = rp.data.data.coursegroup_id;
            //update allData
            const dataKey = group_name + "_" + element;
            // allData[dataKey]["coursegroup_id"] = rp.data.data.coursegroup_id; 
            
          }
          console.log("takoyaki");
          console.log(current_summarizeData);
          // console.log(allData);
          console.log(rp.data.data);

          
          // insert course to database
          for(let element of courses[group_name]){
            console.log("pp")
            console.log(element)
            var is_abnormalA = 0;
            var abnormal_improvement = ""
            var abnormal_cause = "";
            if(summarizeData[group_name][element]["abnormal"] == "true"){
              is_abnormalA = 1;
              abnormal_improvement = current_summarizeData["abnormalCourse"][element]["plan"];
              abnormal_cause = current_summarizeData["abnormalCourse"][element]["cause"];
              
            }
            //console.log(c_obj);
            console.log("VAVA");
            console.log(matchgroup_to_id);
      
      
            var c_obj = {coursegroup_id :Number(matchgroup_to_id[group_name]),
                          improvement_plan : current_summarizeData[group_name][element]["improvementPlan"],
                          remark : current_summarizeData[group_name][element]["note"],
                          is_abnormal : is_abnormalA,
                          abnormal_improvement : abnormal_improvement,
                          abnormal_cause : abnormal_cause,
                          course_no : element.toString()
            }
      
            insert_course(c_obj);
      
          }
          console.log("SAKAAA");
          console.log(insert_order);
          if(insert_order.length > 0){
            insert_group2(insert_order,summarizeData);
          }


        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

   function delete_all_course(coursegroup_id){
    const url = "?q=courseville/ajax/cvtqf7_deleteallcourse";
    
    const data = {coursegroup_id : Number(coursegroup_id)};

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          console.log("delete success");
          
          console.log(rp.data);

          console.log("STEP 2");

        console.log(matchid_to_group);
        console.log(matchgroup_to_id);
        var group = matchid_to_group[Number(coursegroup_id)];
        console.log(coursegroup_id);
        console.log("PPPPP111");
        console.log(group);
        for (let course of courses[group]) {
            var course_group_id = matchgroup_to_id[group];
            var is_abnormalA = 0;
            var abnormal_improvement = "";
            var abnormal_cause = "";
            if (summarizeData[group][course]["abnormal"] === "true") {
                is_abnormalA = 1;
                abnormal_improvement = summarizeData["abnormalCourse"][course]["plan"];
                abnormal_cause = summarizeData["abnormalCourse"][course]["cause"];
            }

            var c_obj = {
                coursegroup_id: Number(course_group_id),
                improvement_plan: summarizeData[group][course]["improvementPlan"],
                remark: summarizeData[group][course]["note"],
                is_abnormal: is_abnormalA,
                abnormal_improvement: abnormal_improvement,
                abnormal_cause: abnormal_cause,
                course_no: course.toString()
            };

            insert_course(c_obj);
        }
        //alert("create new course Done!");
    



        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

  // 1.2 for loop Set2() and load coursename from courseville_course and render
  function renderAbnormalCourse(course){
    // clear previous data
    // $("#AbnormalList").empty();
    console.log(abnormal_course_Set);
    console.log(matchcourse_to_cvcid);
    // for(let course of abnormal_course_Set){

        const courseToAdd = createAbnormalItem(course, match_course_name[course], matchcourse_to_cvcid[course],abnormal_data[course]["abnormal_cause"],abnormal_data[course]["abnormal_improvement"],$(".btn-modify").data("mode")=="view");
        $("#AbnormalList").append(courseToAdd);
    // }
    // // adjust text box
    // $(".abnormal_cause_text").each(function() {
    //   const noteText = $(this).closest("li").find(".abnormal_cause_text")[0];
    //   adjustHeight(this, noteText);
    // });
    // $(".abnormal_improvement_text").each(function() {
    //   const noteText = $(this).closest("li").find(".abnormal_improvement_text")[0];
    //   adjustHeight(this, noteText);
    // });
}

   function submit_summarize_1(){
    // var is_delete_all = false;

    is_render_abnormal = {};
    $("#AbnormalList").empty();

    
    console.log("STEP 1");

    for (let group of already_indb_group) {
        delete_all_course(Number(matchgroup_to_id[group]));
        //alert("delete old course Done!");
        // is_delete_all = true;
    }

    // console.log("STEP 2");

    // for (let group of already_indb_group) {
    //     for (let course of courses[group]) {
    //         var course_group_id = matchgroup_to_id[group];
    //         var is_abnormalA = 0;
    //         var abnormal_improvement = "";
    //         var abnormal_cause = "";
    //         if (summarizeData[group][course]["abnormal"] === "true") {
    //             is_abnormalA = 1;
    //             abnormal_improvement = summarizeData["abnormalCourse"][course]["plan"];
    //             abnormal_cause = summarizeData["abnormalCourse"][course]["cause"];
    //         }

    //         var c_obj = {
    //             coursegroup_id: Number(course_group_id),
    //             improvement_plan: summarizeData[group][course]["improvementPlan"],
    //             remark: summarizeData[group][course]["note"],
    //             is_abnormal: is_abnormalA,
    //             abnormal_improvement: abnormal_improvement,
    //             abnormal_cause: abnormal_cause,
    //             course_no: course.toString()
    //         };

    //         insert_course(c_obj);
    //     }
    //     alert("create new course Done!");
    // }

    // Insert groups


    var insert_order = [];
    for(let element of wait_to_insert_group){
      insert_order.push(element);
    }
    if(insert_order.length > 0){
      insert_group2(insert_order, summarizeData);
    }


    
    // for (let group of wait_to_insert_group) {
    //     insert_group2(group, summarizeData);
    //     already_indb_group.add(group);
    // }

    wait_to_insert_group.clear();
    
    

    console.log(groups);
    console.log(courses);
    console.log(summarizeData);

    

    // Render next page
    //load_abnormal_course();
    //renderAbnormalCourse();
   }


 $(document).ready(function () { 

  console.log("HEREEEEEEE");
  console.log($("#page-4-1").data('value'));
  section_id = $("#page-4-1").data('value');

  

    
  load_report_section(section_id); // load report_section after done.
  
  
  function load_previous_data(){
  }

  function load_content_summarization_coursegroup(content_summarization_id){
    const url = "?q=courseville/ajax/cvtqf7_loadcontentcoursegroup";
    
    const data = {content_summarization_id : content_summarization_id};

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          console.log("load content summarization success");
          console.log(rp.data)
          content_summarization_coursegroup = rp.data;
          
          for(let element of content_summarization_coursegroup){
            console.log(element["coursegroup_id"]);
            summarizeData[element["coursegroup_title"]] = {};
            matchid_to_group[element["coursegroup_id"]] = element["coursegroup_title"];
            matchgroup_to_id[element["coursegroup_title"]] = element["coursegroup_id"];
            // add groups
            groups.push(element["coursegroup_title"]);
            courses[[element["coursegroup_title"]]] = new Set();
            load_content_summarization_coursegroup_course(Number(element["coursegroup_id"]), is_render_current_group);
            if(is_render_current_group == "false"){
              is_render_current_group = "true";
            }
            // add groupBar
            $("#groupBar").append(`
              <li class="groupInBar">
                <span class="font-bold">
                  ${element["coursegroup_title"]}
                </span>
              </li>
            `);

              if(!is_set_current_group){
                is_set_current_group = true;
                currentGroup = element["coursegroup_title"];
                // for auto select current group
                changeGroup();
              }

              already_indb_group.add(element["coursegroup_title"]);

          }

          
        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }
  
  function load_content_summarization_coursegroup_course(coursegroup_id,is_render_current_group){
    const url = "?q=courseville/ajax/cvtqf7_loadcontentcoursegroupcourse";
    
    const data = {coursegroup_id : coursegroup_id};

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          console.log("load course Yay");
          console.log(rp.data)
          if(Object.keys(rp.data).length > 0){
            var coursegroup_id = rp.data[0]["coursegroup_id"];
            content_summarization_coursegroup_course[coursegroup_id] = rp.data;
            for(let element of rp.data){
              // summarizeData[matchid_to_group[coursegroup_id]][]
              load_course_by_cvcid(element,is_render_current_group); // and edit summarizeData in this function
            }
          }
        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

  function add_data_to_summarizeData(){

  }

  function load_all_courses(lp_id){
    const url = "?q=courseville/ajax/cvtqf7_loadallcourses";
    
    const data = {lp_id : lp_id};

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          console.log("load success");
          console.log(rp.data)
          allcourses = rp.data;

          // match_course
          for(let element of allcourses){
            match_course_name[element.orgcourse_no] = element.orgcourse_name_abbr;
            
          }


        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

  function load_report(report_id){
    const url = "?q=courseville/ajax/cvtqf7_loadreport";
    const data = {report_id : report_id};

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          // console.log("load report_section success");
          // report_section = rp.data;
          // console.log(report_section)

          report = rp.data;
          load_all_courses(rp.data.lp_id);
          console.log("KAAAAAAAAA");
          console.log(rp.data);
          console.log(report_section["content_summarization_id"]);

          if(!is_loaded){
            load_content_summarization_coursegroup(report_section["content_summarization_id"]); // load_content_summarization_coursegroup_course in this function too.
            is_loaded = true;
          }
        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

  function load_report_section(section_id){
    const url = "?q=courseville/ajax/cvtqf7_loadreportsection";
    const data = {section_id : section_id};

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          // console.log("load report success");
          // report = rp.data;
          // console.log("banana");
          // console.log(report);
          // load_all_courses();
          console.log("MINGGGG");
          console.log(rp.data);
          report_id = rp.data.report_id;

          report_section = rp.data;
          
          load_report(report_id);


        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

  function load_course(orgcourse_no){
    const url = "?q=courseville/ajax/cvtqf7_loadcourse";
    const data = {course_no : orgcourse_no};
    var course_name = null;

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          console.log("load course name success");
          console.log(rp);
          course_name = rp.data.title;
          console.log(course_name)
        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}

  }

  function load_course_by_cvcid(course_obj,is_render_current_group){
    var cv_cid = course_obj["cv_cid"];
    const url = "?q=courseville/ajax/cvtqf7_loadcourse2";
    const data = {cv_cid : cv_cid};
  
      coursevilleAjaxPost2(
        url,
        data,
        handler_done,
        handler_fail,
        handler_always,
        null
      );
  
      function handler_done(rp, extras, textStatus, jqXHR) {
        if (rp.status == 1) {
          
            console.log("load course by cvcid success");
            console.log(rp.data);

            // add courses
            courses[matchid_to_group[course_obj["coursegroup_id"]]].add(Number(rp.data["course_no"]));

            var is_abnormal = "false";
            checkNormal[rp.data["course_no"]] = "false";
            if(course_obj["is_abnormal"] == "1"){
              console.log("POKEMON");
              console.log(course_obj);
              is_abnormal = "true";
              var obj_to_add2 = {
                cause:course_obj["abnormal_cause"],
                plan:course_obj["abnormal_improvement"]
              }
              summarizeData["abnormalCourse"][rp.data["course_no"]] = obj_to_add2;
              notNormalSubject.add(Number(rp.data["course_no"]));
              checkNormal[rp.data["course_no"]] = "true";
            }
            var obj_to_add = {abnormal : is_abnormal,
                              coursegroup_id : course_obj["coursegroup_id"],
                              improvementPlan : course_obj["improvement_plan"],
                              note : course_obj["remark"]
            } 
            console.log("POKE1");
            console.log(summarizeData);
            console.log(course_obj);
            console.log(obj_to_add);
            console.log(is_abnormal);
            summarizeData[matchid_to_group[course_obj["coursegroup_id"]]][rp.data["course_no"]] = obj_to_add;
            console.log("yay2");
            console.log(summarizeData);
            if(is_render_current_group == "false"){
              renderSubject_bycourse(matchid_to_group[course_obj["coursegroup_id"]],rp.data["course_no"],match_course_name[rp.data["course_no"]]);
            }

          
        } else {
          alert(rp.msg);
        }
      }
      function handler_fail(extras, jqXHR, textStatus, errorThrown) {
        alert(textStatus);
      }
      function handler_always(
        extras,
        jqXHROrData,
        textStatus,
        jqXHROrErrorThrown
      ) {}
  }





  const createSubjectItem = (
    id,
    code,
    name,
    semester,
    score1,
    score2,
    score3,
    data4,
    data5,
    data6,
    datavalue,
    abnormalClass,
    text1,
    text2,
    checked,
    is_abnormal,
    is_view_mode,
  ) => `
<li
  id="${code}"
  data-value="${code}"
  class="grid grid-cols-12 gap-8 my-1 mx-2 p-2 rounded-md delete-gap-when-print ${is_abnormal ? `${abnormalClass}` : 'bg-white'} "
>
  <div class="col-span-2 flex flex-col items-center justify-center">
    <div>${code}</div>
    <div class="text-xs text-center">${name}</div>
    <div class="text-xs">${semester}</div>
  </div>
  <div class="col-span-1 flex flex-col items-center justify-center">
    <div>${score1}</div>
    <a
      href=""
      class="text-xs text-center text-blue-700 underline link-to-grade"
    >
      ดูรายละเอียดเกรด
    </a>
  </div>
  <div class="col-span-1 flex items-center justify-center">
    <div class="flex flex-row gap-4">
      <div>${score2}</div>
      <div>${score3}</div>
    </div>
  </div>
  <div class="col-span-1 flex items-center justify-center">
    ${data4}
  </div>
  <div class="col-span-1 flex items-center justify-center">
    ${data5}
  </div>
  <div class="col-span-1 flex items-center justify-center">
    ${data6}
  </div>
  <div class="col-span-2 flex flex-col">
    <textarea
      class="planText"
      ${is_view_mode ? 'disabled' : ''}
      >${text1}</textarea>
  </div>
  <div class="col-span-1 flex flex-col col-span-2-print">
    <textarea
      class="noteText"
      ${is_view_mode ? 'disabled' : ''}
    >${text2}</textarea>
  </div>
  <div class="col-span-1 flex items-center justify-center">
    <input class="checkNotNormal" type="checkbox" ${checked} ${is_view_mode ? 'disabled' : ''} />
  </div>
  <div class="col-span-1 flex items-center justify-center">
    <button class="deleteSubject ${is_view_mode ? 'hidden' : ''} bg-red-700 text-white py-2 px-4 rounded-lg">

        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path d="M2.8125 1.125C2.51413 1.125 2.22798 1.24353 2.017 1.4545C1.80603 1.66548 1.6875 1.95163 1.6875 2.25V3.375C1.6875 3.67337 1.80603 3.95952 2.017 4.1705C2.22798 4.38147 2.51413 4.5 2.8125 4.5H3.375V14.625C3.375 15.2217 3.61205 15.794 4.03401 16.216C4.45597 16.6379 5.02826 16.875 5.625 16.875H12.375C12.9717 16.875 13.544 16.6379 13.966 16.216C14.3879 15.794 14.625 15.2217 14.625 14.625V4.5H15.1875C15.4859 4.5 15.772 4.38147 15.983 4.1705C16.194 3.95952 16.3125 3.67337 16.3125 3.375V2.25C16.3125 1.95163 16.194 1.66548 15.983 1.4545C15.772 1.24353 15.4859 1.125 15.1875 1.125H11.25C11.25 0.826631 11.1315 0.540483 10.9205 0.329505C10.7095 0.118526 10.4234 0 10.125 0L7.875 0C7.57663 0 7.29048 0.118526 7.0795 0.329505C6.86853 0.540483 6.75 0.826631 6.75 1.125H2.8125ZM6.1875 5.625C6.33668 5.625 6.47976 5.68426 6.58525 5.78975C6.69074 5.89524 6.75 6.03832 6.75 6.1875V14.0625C6.75 14.2117 6.69074 14.3548 6.58525 14.4602C6.47976 14.5657 6.33668 14.625 6.1875 14.625C6.03832 14.625 5.89524 14.5657 5.78975 14.4602C5.68426 14.3548 5.625 14.2117 5.625 14.0625V6.1875C5.625 6.03832 5.68426 5.89524 5.78975 5.78975C5.89524 5.68426 6.03832 5.625 6.1875 5.625ZM9 5.625C9.14918 5.625 9.29226 5.68426 9.39775 5.78975C9.50324 5.89524 9.5625 6.03832 9.5625 6.1875V14.0625C9.5625 14.2117 9.50324 14.3548 9.39775 14.4602C9.29226 14.5657 9.14918 14.625 9 14.625C8.85082 14.625 8.70774 14.5657 8.60225 14.4602C8.49676 14.3548 8.4375 14.2117 8.4375 14.0625V6.1875C8.4375 6.03832 8.49676 5.89524 8.60225 5.78975C8.70774 5.68426 8.85082 5.625 9 5.625ZM12.375 6.1875V14.0625C12.375 14.2117 12.3157 14.3548 12.2102 14.4602C12.1048 14.5657 11.9617 14.625 11.8125 14.625C11.6633 14.625 11.5202 14.5657 11.4148 14.4602C11.3093 14.3548 11.25 14.2117 11.25 14.0625V6.1875C11.25 6.03832 11.3093 5.89524 11.4148 5.78975C11.5202 5.68426 11.6633 5.625 11.8125 5.625C11.9617 5.625 12.1048 5.68426 12.2102 5.78975C12.3157 5.89524 12.375 6.03832 12.375 6.1875Z" fill="white"/>
        </svg>

    </button>
  </div>
</li>
`;

{/* <span class="material-symbols-outlined bg-red-700 text-white py-1 px-3 rounded-lg">
        delete
      </span> */}

const createSubjectInModal = (
  orgcourse_no,
  orgcourse_name_abbr,
  modalType,
) => `
                        <li
                          id="${orgcourse_no}InUnselectedListInAdd${modalType}"
                          data-value="${orgcourse_no}"
                          class="unSelectedItemInAdd${modalType}"
                        >
                          <span class="flex flex-row border-slate-300 border-b rounded-sm bg-white">
                          <div class="flex items-center h-7 mx-3">
                            <input
                              class="checkBoxInAdd${modalType}Modal"
                              type="checkbox"
                            />
                          </div>
                          <div class="flex items-center ">
                            <p class="text-xs">
                              ${orgcourse_no} ${orgcourse_name_abbr}
                            </p>
                          </div>
                          </span>
                        </li>
`;

  const changeGroup = () => {
    // update color in groupBar
    $("#groupBar li").each(function (index, element) {
      if ($(element).find("span").text().trim() == currentGroup) {
        $(element)
          .find("span")
          .addClass("text-white")
        $(element).addClass("selected-group");
      } else {
        $(element)
        .find("span")
        .removeClass("text-white")
        $(element).removeClass("selected-group");
      }
    });
  };

  const changeSubGroup = () => {
    // update color in groupBar
    $("#subGroupBar li").each(function (index, element) {
      if ($(element).find("span").text().trim() == currentSubGroup) {
        $(element)
          .find("span")
          .addClass("text-white")
        $(element)
          .addClass("selected-subgroup");
      } else {
        $(element)
          .find("span")
          .removeClass("text-white")
        $(element)
          .removeClass("selected-subgroup")
      }
    });
  };

  const renderSubject = () => {

    // clear previous page
    $("#subjectList").empty();

    // render subejct in current group
    console.log(courses)
    console.log(currentGroup);
    console.log(courses[currentGroup]);
    if (courses[currentGroup][Symbol.iterator]) {
      for (let element of courses[currentGroup]) {  

        var abnormalClass = ""
        var checked = ""
        var is_abnormal = false;
        if(checkNormal[element] == "true"){
          abnormalClass = "subject-notNormal";
          checked = "checked";
          is_abnormal = true;
        }
        const subject = createSubjectItem(
          "subject1",
          element,
          match_course_name[element],
          "ทวิภาค / ภาคต้น",
          "139",
          "17%",
          "15%",
          "4.07",
          "3.99",
          "4.03",
          element,
          abnormalClass,
          summarizeData[currentGroup][element]["improvementPlan"],
          summarizeData[currentGroup][element]["note"],
          checked,
          is_abnormal,
          $(".btn-modify").data("mode")=="view",
        );
        $("#subjectList").append(subject);

        
      }
    } else {
      console.log("error in renderSubject when you try to render subject");
    }

    // adjust text box
    $(".planText").each(function() {
      const noteText = $(this).closest("li").find(".planText")[0];
      adjustHeight(this, noteText);
    });
    $(".noteText").each(function() {
      const noteText = $(this).closest("li").find(".noteText")[0];
      adjustHeight(this, noteText);
    });

    


  };

  const renderSubject_bycourse = (group,course_no,course_name) => {

    // don't clear previous page
    //$("#subjectList").empty();

    // render subejct in current group


        var abnormalClass = ""
        var checked = ""
        var is_abnormal = false;
        if(summarizeData[group][course_no]["abnormal"] == "true"){
          abnormalClass = "subject-notNormal";
          checked = "checked";
          is_abnormal = true;
        }
        const subject = createSubjectItem(
          "subject1",
          course_no,
          course_name,
          "ทวิภาค / ภาคต้น",
          "139",
          "17%",
          "15%",
          "4.07",
          "3.99",
          "4.03",
          course_no,
          abnormalClass,
          summarizeData[group][course_no]["improvementPlan"],
          summarizeData[group][course_no]["note"],
          checked,
          is_abnormal,
          $(".btn-modify").data("mode")=="view",
        );
        $("#subjectList").append(subject);


    


  };

  const renderSubjectInAddGroup = (filteredcourses) => {
    // clear previous page
    $("#unSelectedListInAddGroupModal").empty();

    var count = 0;

    console.log(filteredcourses)
    // render
    for(let course of filteredcourses){
      const courseA = createSubjectInModal(course.orgcourse_no,course.orgcourse_name_abbr,"Group");
      $("#unSelectedListInAddGroupModal").append(courseA);
      count++;
      if(count == 100){
        return;
      }
    }
    console.log("done1");
    
  };

  const renderSubjectInAddSubject = () => {
    // clear previous page
    $("#unSelectedListInAddSubjectModal").empty();

    var count = 0;

    console.log(allcourses)
    // render
    for(let course of allcourses){
      const courseA = createSubjectInModal(course.orgcourse_no,course.orgcourse_name_abbr,"Subject");
      $("#unSelectedListInAddSubjectModal").append(courseA);
      count++;
      if(count == 100){
        return;
      }
    }
    console.log("done2");
    
  };

  $("#searchInGroupModal").on("keyup",function (){
    var inputText = $(this).val().toLowerCase();
    console.log(inputText);
    
  })

  const renderSubGroupContent = () => {
    // clear previous page
    // $("#subjectList").empty();

    // render subejct in current group
    // TO DO
  };

  const renderInAddGroupModal = () => {
    // clear previous page
    $("#selectedListInAddGroupModal").empty();

    // render subject in selectedSubject_1
    for (let courseNumber of selectedSubject_1) {
      $("#selectedListInAddGroupModal").append(`
        <li id="${courseNumber}InSelectedListInAddGroup" data-value="${courseNumber}" class="">
          <span class="bg-maintheme-striped-color-bg-2 flex flex-row w-full rounded-md">
          <div class="flex items-center justify-center text-center w-full ml-2">
            <p class="text-maintheme-color py-1 smalltext">${courseNumber}</p>
          </div>
          <div class="flex items-center justify-end">
            <button class="deleteInAddGroupModal">
              <span class="text-maintheme-color mr-2 pl-3">x</span>
            </button>
          </div>
          </span>
        </li>
      `);
    }
  };

  const renderInAddSubjectModal = () => {
    // clear previous page
    $("#selectedListInAddSubjectModal").empty();

    // render subject in selectedSubject_2
    for (let courseNumber of selectedSubject_2) {
      $("#selectedListInAddSubjectModal").append(`
          <li id="${courseNumber}InSelectedListInAddSubject" data-value="${courseNumber}" class="">
          <span class="bg-maintheme-striped-color-bg-2 flex flex-row w-full rounded-md">
          <div class="flex items-center justify-center text-center w-full ml-2">
            <p class="text-maintheme-color py-1 smalltext">${courseNumber}</p>
          </div>
          <div class="flex items-center justify-end">
            <button class="deleteInAddSubject">
              <span class="text-maintheme-color mr-2 pl-3">x</span>
            </button>
          </div>
          </span
        </li>
      `);
    }
  };

  const handleAddGroup = () => {
    console.log(summarizeData)

    // create new group with selected subjects
    courses[$("#newGroupName").val()] = new Set([...selectedSubject_1]);
    currentGroup = $("#newGroupName").val();
    groups.push(currentGroup);

    wait_to_insert_group.add(currentGroup);

    console.log("Poke100");
    console.log(checkNormal);
    console.log(summarizeData);

    // update new group to summarizeData
    const objToAdd = {};
    selectedSubject_1.forEach((courseNumber) => {
      console.log("LOL");
      console.log(courseNumber);
      console.log(checkNormal);
      console.log(selectedSubject_1);
      if(checkNormal[Number(courseNumber)] == "true"){
        objToAdd[courseNumber] = {improvementPlan:"",note:"",abnormal:"true",coursegroup_id:null};
        // update allData
        const dataKey = currentGroup + "_" + courseNumber
        // allData[dataKey] = {improvementPlan:"",note:"",abnormal:"true",coursegroup_id:null}; 
      }else{
        objToAdd[courseNumber] = {improvementPlan:"",note:"",abnormal:"false",coursegroup_id:null};
        // update allData
        const dataKey = currentGroup + "_" + courseNumber
        // allData[dataKey] = {improvementPlan:"",note:"",abnormal:"false",coursegroup_id:null}; 
      }
      

    });
    summarizeData[currentGroup] = objToAdd;
    
    courses_toadd = new Set([...selectedSubject_1]);
    //courses[currentGroup] = courses_toadd;
    //console.log(courses);
    console.log("ummm");
    console.log(checkNormal);

    
    // add new group to groupBar
    $("#groupBar").append(`
        
        <li class="groupInBar">
          <span class="font-bold">
            ${$("#newGroupName").val()}
          </span>
        </li>
      `);

    // add group to database (cvtqf7_content_summarize_coursegroup)
    // insert_group(currentGroup,selectedSubject_1);
    // insert after save page
    //insert_group2(currentGroup,summarizeData);
    
    // add course to database (cvtqf7_content_summarize_coursegroup_course)
    // add in insert_group after done

    // close modal
    $("#addGroupModalContent")
      .removeClass("modal-visible")
      .addClass("modal-hidden");
    $("#addGroupModal").addClass("hidden");

    
    // clear selected subject after add
    selectedSubject_1 = new Set();

    // auto select groupBar after add
    changeGroup();

    // render subject after add
    console.log("mingming");
    console.log(summarizeData);
    renderSubject();

    

  };

  function insert_group(group_name,selectedSubject_1){
    const url = "?q=courseville/ajax/cvtqf7_insertcoursegroup";
    const data = {content_summarization_id :Number(report_section.content_summarization_id),
                  coursegroup_title : group_name, 
                  };

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          console.log("insert group success");
          console.log(rp);
          console.log(data);

          // edit coursegroup_id in this allData,summarizeData

          //update matchgroup_to_id
          matchgroup_to_id[currentGroup] = rp.data.data.coursegroup_id;

          for(let element of courses[currentGroup]){
            console.log("zaza")

            //update summarizeData
            summarizeData[currentGroup][element]["coursegroup_id"] = rp.data.data.coursegroup_id;
            //update allData
            const dataKey = currentGroup + "_" + element;
            // allData[dataKey]["coursegroup_id"] = rp.data.data.coursegroup_id; 
            
          }
          console.log("takoyaki");
          console.log(summarizeData);
          // console.log(allData);
          console.log(rp.data.data);

          
          // insert course to database
          for(let element of courses[currentGroup]){
            console.log("pp")
            console.log(element)
            var is_abnormalA = 0;
            if(summarizeData[currentGroup][element]["abnormal"] == "true"){
              is_abnormalA = 1;
            }
            //console.log(c_obj);
            console.log("VAVA");
            console.log(matchgroup_to_id);
      
      
            var c_obj = {coursegroup_id :Number(matchgroup_to_id[currentGroup]),
                          improvement_plan : "",
                          remark : "",
                          is_abnormal : is_abnormalA,
                          abnormal_improvement : "",
                          abnormal_cause : "",
                          course_no : element.toString()
            }
      
            insert_course(c_obj);
      
          }


        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

  

  

  function update_course(course_obj){
    const url = "?q=courseville/ajax/cvtqf7_updatecourse";
    console.log("COCO2");
    console.log(course_obj);
    const data = {cv_cid : null,
                  coursegroup_id : course_obj.coursegroup_id,
                  improvement_plan : course_obj.improvement_plan,
                  remark : course_obj.remark,
                  is_abnormal : course_obj.is_abnormal,
                  abnormal_improvement : course_obj.abnormal_improvement,
                  abnormal_cause : course_obj.abnormal_cause,
                  course_no : course_obj.course_no,
                  };

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          console.log("update course success");
          console.log(rp.data);
        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

  
  const handleAddSubject = () => {

    // add all selected subject to current group
    selectedSubject_2.forEach((courseNumber) => {
      courses[currentGroup].add(courseNumber);
    });

    // add all selected subject to summarizeData[currentGroup]
    // const objToAdd = {};
    selectedSubject_2.forEach((courseNumber) => {
      summarizeData[currentGroup][courseNumber] = {improvementPlan:"",note:"",abnormal:"false",coursegroup_id:matchgroup_to_id[currentGroup]};
      // // update allData
      // const dataKey = currentGroup + "_" + courseNumber
      // allData[dataKey] = {improvementPlan:"",note:"",abnormal:"false"};

      if(checkNormal[Number(courseNumber)] == "true"){
        summarizeData[currentGroup][courseNumber] = {improvementPlan:"",note:"",abnormal:"true",coursegroup_id:matchgroup_to_id[currentGroup]};
        // update allData
        const dataKey = currentGroup + "_" + courseNumber
        // allData[dataKey] = {improvementPlan:"",note:"",abnormal:"true",coursegroup_id:null}; 
      }else{
        summarizeData[currentGroup][courseNumber] = {improvementPlan:"",note:"",abnormal:"false",coursegroup_id:matchgroup_to_id[currentGroup]};
        // update allData
        const dataKey = currentGroup + "_" + courseNumber
        // allData[dataKey] = {improvementPlan:"",note:"",abnormal:"false",coursegroup_id:null}; 
      }
      //summarizeData[currentGroup] = objToAdd;
      


    });

    // add all selected subject to courses
    // selectedSubject_2.forEach((courseNumber) => {
    //   courses[currentGroup].add(courseNumber);
    // });

    // insert course to database (we will do it after save page)
    // for(let element of selectedSubject_2){
    //   console.log("pp3")
    //   console.log(element)
    //   var is_abnormalA = 0;
    //   if(summarizeData[currentGroup][element]["abnormal"] == "true"){
    //     is_abnormalA = 1;
    //   }
    //   //console.log(c_obj);
    //   console.log("VAVA3");
    //   console.log(summarizeData[currentGroup][element]);
    //   console.log(matchgroup_to_id);
    //   // continue here


    //   var c_obj = {coursegroup_id :Number(matchgroup_to_id[currentGroup]),
    //                 improvement_plan : "",
    //                 remark : "",
    //                 is_abnormal : is_abnormalA,
    //                 abnormal_improvement : "",
    //                 abnormal_cause : "",
    //                 course_no : element.toString()
    //   }

    //   insert_course(c_obj);

    // }

    console.log("test2");
    // console.log(courses);


    console.log(summarizeData);

    // close modal
    $("#addSubjectModalContent")
      .removeClass("modal-visible")
      .addClass("modal-hidden");
    $("#addSubjectModal").addClass("hidden");

    // clear selectedSubject after add
    selectedSubject_2 = new Set();

    // Render after add
    renderSubject();
  };

  const handleCheckInAddGroupModal = (event) => {
    const target = $(event.target);

    // update color and add new subject to selectedSubject_1
    if (target.closest("input").is(":checked")) {
      target.closest("span").removeClass("bg-white");
      target.closest("span").addClass("bg-maintheme-striped-color-bg-2");

      const courseA = target.closest("li").data().value;
      console.log(typeof(selectedSubject_1));
      console.log(selectedSubject_1);
      selectedSubject_1.add(courseA);

      $("#selectedListInAddGroupModal").append(`
        <li id="${courseA}InSelectedListInAddGroup" data-value="${courseA}" class="">
          <span class="bg-maintheme-striped-color-bg-2 flex flex-row w-full rounded-md">
          <div class="flex items-center justify-center text-center w-full ml-2">
            <p class="text-maintheme-color py-1 smalltext">${courseA}</p>
          </div>
          <div class="flex items-center justify-end">
            <button class="deleteInAddGroupModal">
              <span class="text-maintheme-color mr-2 pl-3">x</span>
            </button>
          </div>
          </span>
        </li>
      `);

    } else {
      target.closest("span").removeClass("bg-maintheme-striped-color-bg-2");
      target.closest("span").addClass("bg-white");

      const course = target.closest("li").data().value;
      // let newArr = selectedSubject_1.filter((item) => item !== course);
      // selectedSubject_1 = newArr;
      selectedSubject_1.delete(course);

      const ListID = "#"+course+"InSelectedListInAddGroup";
      $(ListID).remove();

    }

    // render subject after check
    //renderInAddGroupModal();
  };

  const handleCheckInAddSubjectModal = (event) => {
    const target = $(event.target);

    // update color and add new subject to selectedSubject_2
    if (target.closest("input").is(":checked")) {
      target.closest("span").removeClass("bg-white");
      target.closest("span").addClass("bg-maintheme-striped-color-bg-2");

      const courseA = target.closest("li").data().value;
      selectedSubject_2.add(courseA);

      $("#selectedListInAddSubjectModal").append(`
        <li id="${courseA}InSelectedListInAddSubject" data-value="${courseA}" class="">
          <span class="bg-maintheme-striped-color-bg-2 flex flex-row w-full rounded-md">
          <div class="flex items-center justify-center text-center w-full ml-2">
            <p class="text-maintheme-color py-1 smalltext">${courseA}</p>
          </div>
          <div class="flex items-center justify-end">
            <button class="deleteInAddSubjectModal">
              <span class="text-maintheme-color mr-2 pl-3">x</span>
            </button>
          </div>
          </span>
        </li>
      `);

    } else {
      target.closest("span").removeClass("bg-maintheme-striped-color-bg-2");
      target.closest("span").addClass("bg-white");

      const course = target.closest("li").data().value;
      // let newArr = selectedSubject_2.filter((item) => item !== course);
      // selectedSubject_2 = newArr;
      selectedSubject_2.delete(course)

      const ListID = "#"+course+"InSelectedListInAddSubject";
      $(ListID).remove();

    }

    // render subject after check
    // console.log(selectedSubject_2);
    // renderInAddSubjectModal();
  };

  var isRenderCourseInModal = false;

  const handleOpenAddGroupModal = () => {

    console.log(notNormalSubject);
    console.log("SAKURA")
    console.log(summarizeData);

    console.log(content_summarization_coursegroup_course);

    console.log(groups);
    console.log(courses);

    console.log("DragonTest");
    console.log(summarizeData["fake"]);
    if (typeof summarizeData["fake"] !== 'undefined') {
      // The property "fake" exists in summarizeData
      console.log("wow mingming1");
  } else {
      // The property "fake" does not exist in summarizeData
      console.log("wow mingming2");
  }

    // open modal
    $("#addGroupModal").removeClass("hidden");
    setTimeout(function () {
      $("#addGroupModalContent")
        .removeClass("modal-hidden")
        .addClass("modal-visible");
    }, 10); // Delay to allow the element to become visible before starting the transition
    if(!isRenderCourseInModal){
      renderSubjectInAddGroup(allcourses);
      isRenderCourseInModal = true;
    }

    // clear previous data
    selectedSubject_1 = new Set();
    $("#selectedListInAddGroupModal").empty();

    $(".unSelectedItemInAddGroup span").removeClass("bg-maintheme-striped-color-bg-2");
    $(".unSelectedItemInAddGroup span").addClass("bg-white");
    $(".unSelectedItemInAddGroup input").prop("checked",false);
    $("#newGroupName").val("");
  };

  var isRenderCourseInSubjectModal = false;

  const handleOpenAddSubjectModal = () => {
    // open modal
    $("#addSubjectModal").removeClass("hidden");
    setTimeout(function () {
      $("#addSubjectModalContent")
        .removeClass("modal-hidden")
        .addClass("modal-visible");
    }, 10); // Delay to allow the element to become visible before starting the transition
    if(!isRenderCourseInSubjectModal){
      renderSubjectInAddSubject();
      isRenderCourseInSubjectModal = true;
    }



    // clear previous data
    selectedSubject_2 = new Set();
    $("#selectedListInAddSubjectModal").empty();

    $(".unSelectedItemInAddSubject span").removeClass("bg-maintheme-striped-color-bg-2");
    $(".unSelectedItemInAddSubject span").addClass("bg-white");
    $(".unSelectedItemInAddSubject input").prop("checked",false);
  };



  // .off use for fix bug (it adds 2 times when click AddGroup or AddSubject button)
  // it might be a bad solution
  // fix later
  $("#addGroup").off("click").on("click", handleAddGroup);
  $("#addSubject").off("click").on("click", handleAddSubject);

  //$(".checkBoxInAddGroupModal").on("change", handleCheckInAddGroupModal);
  //$(".checkBoxInAddSubjectModal").on("change", handleCheckInAddSubjectModal);

  $("#openAddGroupModal").on("click", handleOpenAddGroupModal);
  $("#openAddSubjectModal").on("click", handleOpenAddSubjectModal);

  // close modal (click at the grey background)
  $("#addGroupModal").click(function (event) {
    if (event.target == this) {
      $("#addGroupModalContent")
        .removeClass("modal-visible")
        .addClass("modal-hidden");

      $("#addGroupModal").addClass("hidden");
    }
  });

  // close modal (click at the grey background)
  $("#addSubjectModal").click(function (event) {
    if (event.target == this) {
      $("#addSubjectModalContent")
        .removeClass("modal-visible")
        .addClass("modal-hidden");

      $("#addSubjectModal").addClass("hidden");
    }
  });

  // for changeGroup (need to use $(document) instead )
  $(document).on("click", ".groupInBar", function () {
    // .trim for clear white space when access the text
    currentGroup = $(this).find("span").text().trim();

    // call changeGroup
    changeGroup();

    // render subject after change group
    renderSubject();
  });

  $(document).on("click", ".subGroupInBar", function () {
    // .trim for clear white space when access the text
    currentSubGroup = $(this).find("span").text().trim();

    // call changeSubGroup
    changeSubGroup();

    // render subGroupContent after change group
    renderSubGroupContent();
  });

  function handleCheckNotNormal(target){
    console.log("DragonDragon");
    const courseNumber = target.closest("li").data().value;
    if (target.closest("input").is(":checked")) {
      target.closest("li").removeClass("bg-white");
      target.closest("li").addClass("subject-notNormal");
      notNormalSubject.add(courseNumber);

      //update summarizeData
      summarizeData["abnormalCourse"][courseNumber] = {cause:"",plan:""}
      for(let group of groups){
        if(typeof summarizeData[group][courseNumber] !== 'undefined'){
          summarizeData[group][courseNumber]["abnormal"] = "true";
        }
      }


      // update allData
      for(let group of groups){
        const dataKey = group + "_" + courseNumber
        // this if check that this group has this courseNumber before change the data.
        if(typeof summarizeData[group][courseNumber] !== 'undefined'){
          // allData[dataKey]["abnormal"] = "true";
        }
      }

      //update checkNormal
      checkNormal[courseNumber] = "true";

    } else {
      target.closest("li").removeClass("subject-notNormal");
      target.closest("li").addClass("bg-white");
      notNormalSubject.delete(courseNumber);

      //update summarizeData
      delete summarizeData["abnormalCourse"].courseNumber
      for(let group of groups){
        if(typeof summarizeData[group][courseNumber] !== 'undefined'){
          summarizeData[group][courseNumber]["abnormal"] = "false";
        }
      }

      // update allData
      for(let group of groups){
        const dataKey = group + "_" + courseNumber
        // this if check that this group has this courseNumber before change the data.
        if(typeof summarizeData[group][courseNumber] !== 'undefined'){
          // allData[dataKey]["abnormal"] = "false";
        }
      }

      //update checkNormal
      checkNormal[courseNumber] = "false";

    }
  }

  // $(document).on("keyup", ".planText", function () {
  //     var inputText = $(this).val();
  //     //$(this).data('value',inputText);

  //     const courseNumber = $(this).closest("li").data().value;

  //     summarizeData[currentGroup][courseNumber]["improvementPlan"] = inputText;
  //     // update allData
  //     const dataKey = currentGroup + "_" + courseNumber;
  //     // allData[dataKey]["improvementPlan"] = inputText;

  //     this.style.height = 'auto';
  //     this.style.height = this.scrollHeight + 10 + "px";
  // });

  // $(document).on("keyup", ".noteText", function () {
  //     var inputText = $(this).val();
  //     //$(this).data('value',inputText);

  //     const courseNumber = $(this).closest("li").data().value;

  //     summarizeData[currentGroup][courseNumber]["note"] = inputText;
  //     // update allData
  //     const dataKey = currentGroup + "_" + courseNumber;
  //     // allData[dataKey]["note"] = inputText;

  //     this.style.height = 'auto';
  //     this.style.height = this.scrollHeight + 10 + "px";
  //     console.log(summarizeData);
  //     // console.log(allData);
  // });

  function adjustHeight(textarea1, textarea2) {
    const height1 = textarea1.scrollHeight + 10;
    const height2 = textarea2.scrollHeight + 10;
    const newHeight = Math.max(height1, height2);

    textarea1.style.height = 'auto';
    textarea1.style.height = newHeight + "px";
    textarea2.style.height = 'auto';
    textarea2.style.height = newHeight + "px";

    // plan_height = newHeight/4;
    // note_height = newHeight/4;

}

$(document).on("keyup", ".planText", function () {
    var inputText = $(this).val();
    const courseNumber = $(this).closest("li").data().value;

    summarizeData[currentGroup][courseNumber]["improvementPlan"] = inputText;

    const noteText = $(this).closest("li").find(".noteText")[0];
    adjustHeight(this, noteText);

    $(this).closest("p").text(inputText);

});

$(document).on("keyup", ".noteText", function () {
    var inputText = $(this).val();
    const courseNumber = $(this).closest("li").data().value;

    summarizeData[currentGroup][courseNumber]["note"] = inputText;

    const planText = $(this).closest("li").find(".planText")[0];
    adjustHeight(planText, this);

    $(this).closest("p").text(inputText);

    console.log(summarizeData);
});

function adjustHeight(textarea1, textarea2) {
    textarea1.style.height = 'auto';
    textarea2.style.height = 'auto';
    const height = Math.max(textarea1.scrollHeight, textarea2.scrollHeight) + 10;
    textarea1.style.height = height + "px";
    textarea2.style.height = height + "px";


    // plan_height = height/4;
    // note_height = height/4;

}

  $("#csv-input").off("change").on("change", function (event){
    //selected.length = 0;
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(e) {
        console.log("mingming");
        const contents = e.target.result;
        const rows = contents.split('\n');
      
        // Skip the first row (header) and process the rest
        const columnA = rows.slice(1) // Skip the first row
        .map(row => row.split(',')[0].replace(/\r/g, '').trim()) // Remove \r and trim spaces
        .filter(value => value !== ''); // Remove any empty values
      
        console.log(columnA); // This is where you can use the array
        let msg = '';
        columnA.forEach(course_no => {
            selectedSubject_1.add(course_no);
            var id_to_check = "#" + course_no + "InUnselectedListInAddGroup" + " " + 'input[type="checkbox"]';
            var id_to_change_color = "#" + course_no + "InUnselectedListInAddGroup" + " " + 'span';
            $(id_to_check).prop('checked',true);
            $(id_to_change_color).removeClass("bg-white").addClass("bg-maintheme-striped-color-bg-2");
            $("#selectedListInAddGroupModal").append(`
              <li id="${course_no}InSelectedListInAddGroup" data-value="${course_no}" class="">
                  <span class="bg-maintheme-striped-color-bg-2 flex flex-row w-full rounded-md">
                  <div class="flex items-center justify-center text-center w-full ml-2">
                      <p class="text-maintheme-color py-1 smalltext">${course_no} ${match_course_name[course_no]}</p>
                  </div>
                  <div class="flex items-center justify-end mr-2 ml-3">
                      <button class="deleteInAddGroupModal">
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
                          <path d="M2.91174 1.81659L5.99974 4.90459L9.07174 1.83259C9.1396 1.76036 9.22134 1.70258 9.31207 1.66272C9.4028 1.62285 9.50065 1.60172 9.59974 1.60059C9.81191 1.60059 10.0154 1.68487 10.1654 1.8349C10.3155 1.98493 10.3997 2.18841 10.3997 2.40059C10.4016 2.49867 10.3834 2.5961 10.3463 2.68689C10.3091 2.77769 10.2538 2.85993 10.1837 2.92859L7.07174 6.00059L10.1837 9.11259C10.3156 9.24158 10.3929 9.41626 10.3997 9.60059C10.3997 9.81276 10.3155 10.0162 10.1654 10.1663C10.0154 10.3163 9.81191 10.4006 9.59974 10.4006C9.49778 10.4048 9.39606 10.3878 9.30103 10.3506C9.20601 10.3134 9.11975 10.2569 9.04774 10.1846L5.99974 7.09659L2.91974 10.1766C2.85214 10.2464 2.77139 10.3021 2.68214 10.3406C2.59289 10.379 2.49691 10.3994 2.39974 10.4006C2.18757 10.4006 1.98408 10.3163 1.83405 10.1663C1.68402 10.0162 1.59974 9.81276 1.59974 9.60059C1.59787 9.5025 1.61607 9.40508 1.65322 9.31428C1.69036 9.22349 1.74567 9.14124 1.81574 9.07259L4.92774 6.00059L1.81574 2.88859C1.68389 2.75959 1.60657 2.58492 1.59974 2.40059C1.59974 2.18841 1.68402 1.98493 1.83405 1.8349C1.98408 1.68487 2.18757 1.60059 2.39974 1.60059C2.59174 1.60299 2.77574 1.68059 2.91174 1.81659Z" fill="#018ADA"/>
                        </svg>
                      </button>
                  </div>
                  </span>
              </li>
          `);
        });
        if(msg !== ''){
            swal("Name not found", msg, "error");
        }
        // updateTags(selected);
        $('#csv-input').val('');
      };
      reader.readAsText(file);
    }else{
      console.log("import error")
    }
    //alert("add file1");
    console.log(selectedSubject_1);
  })

  $("#csv-input-2").off("change").on("change", function (event){
    //selected.length = 0;
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(e) {
        console.log("mingming");
        const contents = e.target.result;
        const rows = contents.split('\n');
      
        // Skip the first row (header) and process the rest
        const columnA = rows.slice(1) // Skip the first row
        .map(row => row.split(',')[0].replace(/\r/g, '').trim()) // Remove \r and trim spaces
        .filter(value => value !== ''); // Remove any empty values
      
        console.log(columnA); // This is where you can use the array
        let msg = '';
        columnA.forEach(course_no => {
            selectedSubject_2.add(course_no);
            var id_to_check = "#" + course_no + "InUnselectedListInAddSubject" + " " + 'input[type="checkbox"]';
            var id_to_change_color = "#" + course_no + "InUnselectedListInAddSubject" + " " + 'span';
            $(id_to_check).prop('checked',true);
            $(id_to_change_color).removeClass("bg-white").addClass("bg-maintheme-striped-color-bg-2");
            $("#selectedListInAddSubjectModal").append(`
              <li id="${course_no}InSelectedListInAddSubject" data-value="${course_no}" class="">
                  <span class="bg-maintheme-striped-color-bg-2 flex flex-row w-full rounded-md">
                  <div class="flex items-center justify-center text-center w-full ml-2">
                      <p class="text-maintheme-color py-1 smalltext">${course_no} ${match_course_name[course_no]}</p>
                  </div>
                  <div class="flex items-center justify-end mr-2 ml-3">
                      <button class="deleteInAddSubjectModal">
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
                          <path d="M2.91174 1.81659L5.99974 4.90459L9.07174 1.83259C9.1396 1.76036 9.22134 1.70258 9.31207 1.66272C9.4028 1.62285 9.50065 1.60172 9.59974 1.60059C9.81191 1.60059 10.0154 1.68487 10.1654 1.8349C10.3155 1.98493 10.3997 2.18841 10.3997 2.40059C10.4016 2.49867 10.3834 2.5961 10.3463 2.68689C10.3091 2.77769 10.2538 2.85993 10.1837 2.92859L7.07174 6.00059L10.1837 9.11259C10.3156 9.24158 10.3929 9.41626 10.3997 9.60059C10.3997 9.81276 10.3155 10.0162 10.1654 10.1663C10.0154 10.3163 9.81191 10.4006 9.59974 10.4006C9.49778 10.4048 9.39606 10.3878 9.30103 10.3506C9.20601 10.3134 9.11975 10.2569 9.04774 10.1846L5.99974 7.09659L2.91974 10.1766C2.85214 10.2464 2.77139 10.3021 2.68214 10.3406C2.59289 10.379 2.49691 10.3994 2.39974 10.4006C2.18757 10.4006 1.98408 10.3163 1.83405 10.1663C1.68402 10.0162 1.59974 9.81276 1.59974 9.60059C1.59787 9.5025 1.61607 9.40508 1.65322 9.31428C1.69036 9.22349 1.74567 9.14124 1.81574 9.07259L4.92774 6.00059L1.81574 2.88859C1.68389 2.75959 1.60657 2.58492 1.59974 2.40059C1.59974 2.18841 1.68402 1.98493 1.83405 1.8349C1.98408 1.68487 2.18757 1.60059 2.39974 1.60059C2.59174 1.60299 2.77574 1.68059 2.91174 1.81659Z" fill="#018ADA"/>
                        </svg>
                      </button>
                  </div>
                  </span>
              </li>
          `);
        });
        if(msg !== ''){
            swal("Name not found", msg, "error");
        }
        // updateTags(selected);
        $('#csv-input').val('');
      };
      reader.readAsText(file);
    }else{
      console.log("import error")
    }
    //alert("add file1");
    console.log(selectedSubject_2);
  })

  // can not use $(.deleteInAddGroupModal) for <li> that create by .append(<li>...<li>)
  $(document).on("click", ".deleteInAddGroupModal", function () {
    // delete subject in selectedSubject_1
    const course = $(this).closest("li").data().value;
    // let newArr = selectedSubject_1.filter((item) => item !== course);
    // selectedSubject_1 = newArr;
    selectedSubject_1.delete(course);

    const target = $(this).closest("li");

    // update checkBox (uncheck if delete)
    // $("#unSelectedListInAddGroupModal li").each(function (index, element) {
    //   if ($(element).find("input[type='checkbox']").prop("checked")) {
    //     let isdelete = $(element).data().value == target.data().value;
    //     if (isdelete) {
    //       $(element)
    //         .find("input[type='checkbox']")
    //         .prop("checked", !isdelete);
    //       $(element).removeClass("bg-blue-100");
    //       $(element).addClass("bg-white");
    //     }
    //   }
    // });

    const checkBoxID = "#"+target.data().value+"InUnselectedListInAddGroup"+" "+"input";
    $(checkBoxID).closest("span").removeClass("bg-maintheme-striped-color-bg-2");
    $(checkBoxID).closest("span").addClass("bg-white");
    $(checkBoxID).prop("checked",false);

    $(this).closest("li").remove();
  });

  $(document).on("click", ".deleteInAddSubjectModal", function () {
    // delete subject in selectedSubject_2
    const course = $(this).closest("li").data().value;
    // let newArr = selectedSubject_2.filter((item) => item !== course);
    // selectedSubject_2 = newArr;
    selectedSubject_2.delete(course);

    const target = $(this).closest("li");

    const checkBoxID = "#"+target.data().value+"InUnselectedListInAddSubject"+" "+"input";
    $(checkBoxID).closest("span").removeClass("bg-maintheme-striped-color-bg-2");
    $(checkBoxID).closest("span").addClass("bg-white");
    $(checkBoxID).prop("checked",false);

    $(this).closest("li").remove();
  });

  $(document).off("change").on("change", ".checkBoxInAddGroupModal, .checkBoxInAddSubjectModal, .checkNotNormal", function (event) {
    const target = $(this);
    if (target.hasClass("checkBoxInAddGroupModal")) {
        handleGroupModalChange(target);
    } else if (target.hasClass("checkBoxInAddSubjectModal")) {
        handleSubjectModalChange(target);
    } else if (target.hasClass("checkNotNormal")){
        handleCheckNotNormal(target);
    }
});

function handleGroupModalChange(target) {
    console.log("whyyyyy");

    console.log(summarizeData);

    if (target.closest("input").is(":checked")) {
        target.closest("span").removeClass("bg-white").addClass("bg-maintheme-striped-color-bg-2");

        console.log("Mingming123");
        const courseA = target.closest("li").data().value;
        console.log(typeof(selectedSubject_1));
        console.log(selectedSubject_1);
        selectedSubject_1.add(courseA);

        $("#selectedListInAddGroupModal").append(`
            <li id="${courseA}InSelectedListInAddGroup" data-value="${courseA}" class="">
                <span class="bg-maintheme-striped-color-bg-2 flex flex-row w-full rounded-md">
                <div class="flex items-center justify-center text-center w-full ml-2">
                    <p class="text-maintheme-color py-1 smalltext">${courseA} ${match_course_name[courseA]}</p>
                </div>
                <div class="flex items-center justify-end mr-2 ml-3">
                    <button class="deleteInAddGroupModal">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
                        <path d="M2.91174 1.81659L5.99974 4.90459L9.07174 1.83259C9.1396 1.76036 9.22134 1.70258 9.31207 1.66272C9.4028 1.62285 9.50065 1.60172 9.59974 1.60059C9.81191 1.60059 10.0154 1.68487 10.1654 1.8349C10.3155 1.98493 10.3997 2.18841 10.3997 2.40059C10.4016 2.49867 10.3834 2.5961 10.3463 2.68689C10.3091 2.77769 10.2538 2.85993 10.1837 2.92859L7.07174 6.00059L10.1837 9.11259C10.3156 9.24158 10.3929 9.41626 10.3997 9.60059C10.3997 9.81276 10.3155 10.0162 10.1654 10.1663C10.0154 10.3163 9.81191 10.4006 9.59974 10.4006C9.49778 10.4048 9.39606 10.3878 9.30103 10.3506C9.20601 10.3134 9.11975 10.2569 9.04774 10.1846L5.99974 7.09659L2.91974 10.1766C2.85214 10.2464 2.77139 10.3021 2.68214 10.3406C2.59289 10.379 2.49691 10.3994 2.39974 10.4006C2.18757 10.4006 1.98408 10.3163 1.83405 10.1663C1.68402 10.0162 1.59974 9.81276 1.59974 9.60059C1.59787 9.5025 1.61607 9.40508 1.65322 9.31428C1.69036 9.22349 1.74567 9.14124 1.81574 9.07259L4.92774 6.00059L1.81574 2.88859C1.68389 2.75959 1.60657 2.58492 1.59974 2.40059C1.59974 2.18841 1.68402 1.98493 1.83405 1.8349C1.98408 1.68487 2.18757 1.60059 2.39974 1.60059C2.59174 1.60299 2.77574 1.68059 2.91174 1.81659Z" fill="#018ADA"/>
                      </svg>
                    </button>
                </div>
                </span>
            </li>
        `);
    } else {
        target.closest("span").removeClass("bg-maintheme-striped-color-bg-2").addClass("bg-white");

        const course = target.closest("li").data().value;
        selectedSubject_1.delete(course);

        const ListID = `#${course}InSelectedListInAddGroup`;
        $(ListID).remove();
    }

    // <span class="text-maintheme-color mr-2 pl-3">x</span>
}

function handleSubjectModalChange(target) {
    if (target.closest("input").is(":checked")) {
        target.closest("span").removeClass("bg-white").addClass("bg-maintheme-striped-color-bg-2");

        console.log("Mingming1234");
        const courseA = target.closest("li").data().value;
        console.log(typeof(selectedSubject_2));
        console.log(selectedSubject_2);
        selectedSubject_2.add(courseA);

        $("#selectedListInAddSubjectModal").append(`
            <li id="${courseA}InSelectedListInAddSubject" data-value="${courseA}" class="">
                <span class="bg-maintheme-striped-color-bg-2 flex flex-row w-full rounded-md">
                <div class="flex items-center justify-center text-center w-full ml-2">
                    <p class="text-maintheme-color py-1 smalltext">${courseA} ${match_course_name[courseA]}</p>
                </div>
                <div class="flex items-center justify-end mr-2 ml-3">
                    <button class="deleteInAddSubjectModal">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
                        <path d="M2.91174 1.81659L5.99974 4.90459L9.07174 1.83259C9.1396 1.76036 9.22134 1.70258 9.31207 1.66272C9.4028 1.62285 9.50065 1.60172 9.59974 1.60059C9.81191 1.60059 10.0154 1.68487 10.1654 1.8349C10.3155 1.98493 10.3997 2.18841 10.3997 2.40059C10.4016 2.49867 10.3834 2.5961 10.3463 2.68689C10.3091 2.77769 10.2538 2.85993 10.1837 2.92859L7.07174 6.00059L10.1837 9.11259C10.3156 9.24158 10.3929 9.41626 10.3997 9.60059C10.3997 9.81276 10.3155 10.0162 10.1654 10.1663C10.0154 10.3163 9.81191 10.4006 9.59974 10.4006C9.49778 10.4048 9.39606 10.3878 9.30103 10.3506C9.20601 10.3134 9.11975 10.2569 9.04774 10.1846L5.99974 7.09659L2.91974 10.1766C2.85214 10.2464 2.77139 10.3021 2.68214 10.3406C2.59289 10.379 2.49691 10.3994 2.39974 10.4006C2.18757 10.4006 1.98408 10.3163 1.83405 10.1663C1.68402 10.0162 1.59974 9.81276 1.59974 9.60059C1.59787 9.5025 1.61607 9.40508 1.65322 9.31428C1.69036 9.22349 1.74567 9.14124 1.81574 9.07259L4.92774 6.00059L1.81574 2.88859C1.68389 2.75959 1.60657 2.58492 1.59974 2.40059C1.59974 2.18841 1.68402 1.98493 1.83405 1.8349C1.98408 1.68487 2.18757 1.60059 2.39974 1.60059C2.59174 1.60299 2.77574 1.68059 2.91174 1.81659Z" fill="#018ADA"/>
                      </svg>
                    </button>
                </div>
                </span>
            </li>
        `);
    } else {
        target.closest("span").removeClass("bg-maintheme-striped-color-bg-2").addClass("bg-white");

        const course = target.closest("li").data().value;
        selectedSubject_2.delete(course);

        const ListID = `#${course}InSelectedListInAddSubject`;
        $(ListID).remove();
    }
}

  // for subjects that is added by add group modal
  $(document).on("click", ".deleteSubject", function () {

    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        // Perform the delete action here
        Swal.fire(
          'Deleted!',
          'Your item has been deleted.',
          'success'
        );

        const course_no = $(this).closest("li").data().value;
        var group_id = summarizeData[currentGroup][course_no]["coursegroup_id"];

        $(this).closest("li").remove();
        courses[currentGroup].delete(course_no);
        const dataKey = currentGroup+"_"+course_no;
        // delete allData[dataKey];

        if(summarizeData[currentGroup][course_no]["abnormal"] == "true"){
          //abnormal_Set[group_id].delete(course_no);
          //abnormal_course_Set.delete(course_no);
          console.log('testDelete1')
          console.log(summarizeData)
          // delete summarizeData["abnormalCourse"].course_no;
          console.log('testDelete2')
          console.log(summarizeData)

          // improve this later (this is so slow)
          // for(let group of groups){
          //   for(let course of courses[group]){
          //       if(course == course_no){
          //         summarizeData[group][course]["abnormal"] = "false";
          //       }
          //   }
          // }

          // summarizeData[currentGroup][course_no]["abnormal"] = "false";
          // notNormalSubject.delete(course_no);
          // checkNormal[course_no] = "false"
        }

        // deletecourse(group_id,matchcourse_to_cvcid[course_no]);
        // delete after save page

        delete summarizeData[currentGroup][course_no]; // do this after update summarizeData!
      }
    });


  });

  // renderSubjectInAddGroup();

  // $("#addGroup").off("click").on("click", handleAddGroup);
  // $("#addSubject").off("click").on("click", handleAddSubject);

  function deletecourse(coursegroup_id,cv_cid){
    const url = "?q=courseville/ajax/cvtqf7_deletecourse";
    
    const data = {coursegroup_id : Number(coursegroup_id),
                  cv_cid : Number(cv_cid)};

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          console.log("delete success");
          
          console.log(rp.data);

        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

  function deletegroup(coursegroup_id,content_summarization_id){
    const url = "?q=courseville/ajax/cvtqf7_deletegroup";
    
    const data = {coursegroup_id : Number(coursegroup_id),
                  content_summarization_id : Number(content_summarization_id)};

    coursevilleAjaxPost2(
      url,
      data,
      handler_done,
      handler_fail,
      handler_always,
      null
    );

    function handler_done(rp, extras, textStatus, jqXHR) {
      if (rp.status == 1) {
        
          console.log("delete success");
          
          console.log(rp.data);

        
      } else {
        alert(rp.msg);
      }
    }
    function handler_fail(extras, jqXHR, textStatus, errorThrown) {
      alert(textStatus);
    }
    function handler_always(
      extras,
      jqXHROrData,
      textStatus,
      jqXHROrErrorThrown
    ) {}
  }

  // This is for next page (4.2) to render after Next button

  


  // step 1

        // 1.1 use summarizeData to get all cv_cid and course_no and course_name and add to Set2()
        // define at the top of the file
        // var abnormal_Set = {};
        // var abnormal_groupSet = new Set();
        // var abnormal_course_Set = new Set();
        function load_abnormal_course(){
            abnormal_Set = {};
            abnormal_groupSet.clear();
            abnormal_course_Set.clear();
            $("#AbnormalList").empty();
            var is_render_abnormal = {};
            for(let group of groups){
              var course_group_id = matchgroup_to_id[group];
                    for(let course of courses[group]){
                      if(summarizeData[group][course]["abnormal"] == "true"){
                          // var group_id = summarizeData[group][course]["coursegroup_id"];
                          abnormal_groupSet.add(course_group_id);
                          if(typeof abnormal_Set[course_group_id] !== "undefined"){
                              abnormal_Set[course_group_id].add(course);
                          }else{
                              abnormal_Set[course_group_id] = new Set([course]);
                          }
      
                          abnormal_course_Set.add(course);
                          console.log("Nobita");
                          console.log(summarizeData);
                          console.log(course);
                          abnormal_data[course] = {abnormal_cause:summarizeData["abnormalCourse"][course]["cause"],
                                                   abnormal_improvement : summarizeData["abnormalCourse"][course]["plan"]
                          }
                          
                          if(typeof is_render_abnormal[course] !== "undefined"){
                            console.log("is rendered")
                          }else{
                            renderAbnormalCourse(course);
                            is_render_abnormal[course]  = true;
                          }

                          // abnormal_course_Set.add({course_no:course,
                          //   abnormal_cause:summarizeData["abnormalCourse"]["cause"],
                          //   abnormal_improvement : summarizeData["abnormalCourse"][course]["note"],
                          // });
                      }
                  }


                
            }
            console.log("Pika");
            console.log(abnormal_Set);
            console.log(abnormal_course_Set);
            console.log(abnormal_groupSet);
            console.log(abnormal_data);

            

        }

        

  // $("#submitForNext").off("click").on("click",async function(){

  //   for(let group of already_indb_group){
  //     delete_all_course(Number(matchgroup_to_id[group]));
  //     alert("delete old course Done!");
  //   }

  //   console.log(groups);
  //   console.log(courses);
  //   console.log(summarizeData);

  //   for(let group of already_indb_group){
  //     for(let course of courses[group]){
  //       var course_group_id = matchgroup_to_id[group];
  //       var is_abnormalA = 0;
  //       var abnormal_improvement = ""
  //       var abnormal_cause = "";
  //       if(summarizeData[group][course]["abnormal"] == "true"){
  //         is_abnormalA = 1;
  //         abnormal_improvement = summarizeData["abnormalCourse"][course]["plan"];
  //         abnormal_cause = summarizeData["abnormalCourse"][course]["cause"];
          
  //       }
  
  //       var c_obj = {coursegroup_id :Number(course_group_id),
  //                     improvement_plan : summarizeData[group][course]["improvementPlan"],
  //                     remark : summarizeData[group][course]["note"],
  //                     is_abnormal : is_abnormalA,
  //                     abnormal_improvement : abnormal_improvement,
  //                     abnormal_cause : abnormal_cause,
  //                     course_no : course.toString()
  //       }
  
  //       insert_course(c_obj);
      
  //     }
  //     alert("create new course Done!");
  //   }


  //   // insert course
  //   for(let group of wait_to_insert_group){
  //     insert_group2(group,summarizeData);
  //     already_indb_group.add(group);
  //   }
  //   wait_to_insert_group.clear();
    
   

  //   // render next page
  //   load_abnormal_course();
  //   renderAbnormalCourse();

      
  // })


  $("#submitForNext").off("click").on("click", async function() {
    // var is_delete_all = false;

    is_render_abnormal = {};
    $("#AbnormalList").empty();

    
    console.log("STEP 1");

    for (let group of already_indb_group) {
        delete_all_course(Number(matchgroup_to_id[group]));
        alert("delete old course Done!");
        // is_delete_all = true;
    }

    // console.log("STEP 2");

    // for (let group of already_indb_group) {
    //     for (let course of courses[group]) {
    //         var course_group_id = matchgroup_to_id[group];
    //         var is_abnormalA = 0;
    //         var abnormal_improvement = "";
    //         var abnormal_cause = "";
    //         if (summarizeData[group][course]["abnormal"] === "true") {
    //             is_abnormalA = 1;
    //             abnormal_improvement = summarizeData["abnormalCourse"][course]["plan"];
    //             abnormal_cause = summarizeData["abnormalCourse"][course]["cause"];
    //         }

    //         var c_obj = {
    //             coursegroup_id: Number(course_group_id),
    //             improvement_plan: summarizeData[group][course]["improvementPlan"],
    //             remark: summarizeData[group][course]["note"],
    //             is_abnormal: is_abnormalA,
    //             abnormal_improvement: abnormal_improvement,
    //             abnormal_cause: abnormal_cause,
    //             course_no: course.toString()
    //         };

    //         insert_course(c_obj);
    //     }
    //     alert("create new course Done!");
    // }
// ******************************************************* */
//     // Insert groups


//     var insert_order = [];
//     for(let element of wait_to_insert_group){
//       insert_order.push(element);
//     }
//     if(insert_order.length > 0){
//       insert_group2(insert_order, summarizeData);
//     }


    
//     // for (let group of wait_to_insert_group) {
//     //     insert_group2(group, summarizeData);
//     //     already_indb_group.add(group);
//     // }

//     wait_to_insert_group.clear();
    
    

//     console.log(groups);
//     console.log(courses);
//     console.log(summarizeData);

    

//     // Render next page
//     //load_abnormal_course();
//     //renderAbnormalCourse();


});



    
   
})